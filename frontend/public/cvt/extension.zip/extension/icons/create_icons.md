# Icon Creation Guide

Create the following icons for the extension:

- icon-16.png (16x16 pixels)
- icon-32.png (32x32 pixels)  
- icon-48.png (48x48 pixels)
- icon-128.png (128x128 pixels)

Use a simple chat/sync icon design with blue/purple colors to match the extension theme.

You can use any icon creation tool or online generator. The icons should be PNG format.

For now, you can use placeholder icons or remove the icons section from manifest.json if needed.
